using UnityEngine;

public struct CharacterToDisplay
{
    public string Id;
    public Sprite Sprite;
}