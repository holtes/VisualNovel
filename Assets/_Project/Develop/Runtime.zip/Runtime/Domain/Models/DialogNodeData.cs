using System;
using System.Collections.Generic;
using UnityEngine;

public struct DialogNodeData
{
    public string Text;
    public Sprite Background;
    public SpeakerNameUIData SpeakerName;
    public List<CharacterToDisplay> Characters;
    public List<ChoiceUIData> Choices;
    public Type NodeType;
}