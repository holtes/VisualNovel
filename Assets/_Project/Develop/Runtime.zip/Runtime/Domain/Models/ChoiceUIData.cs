public struct ChoiceUIData
{
    public string Text;
    public string ChoiceId;
}