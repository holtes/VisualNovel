using UnityEngine;

public struct SpeakerNameUIData
{
    public string SpeakerName;
    public Color NameColor;
}
