using UnityEngine;
using R3;
using Zenject;
using System.Collections.Generic;
using System.Linq;

public class DialogController : MonoBehaviour
{
    [SerializeField] private DialogWindowView _dialogWindowView;
    [SerializeField] private CharactersContainerView _charactersContainerView;
    [SerializeField] private BackgroundView _backgroundView;
    [SerializeField] private ChoiceViewList _choiceViewList;

    private DialogModel _model;
    private ICharacterLibrary _characterLibrary;

    [Inject]
    private void Construct(DialogModel dialogModel, ICharacterLibrary characterLibrary)
    {
        _model = dialogModel;
        _characterLibrary = characterLibrary;
    }

    private void Start()
    {
        _dialogWindowView.OnNextBtnClicked
            .Subscribe(_ => HandleNext())
            .AddTo(this);

        _dialogWindowView.OnPreviousBtnClicked
            .Subscribe(_ => HandleBack())
            .AddTo(this);

        Show(_model.GetCurrentNode());
    }

    private void HandleNext()
    {
        if (_model.TryGoNext()) Show(_model.GetCurrentNode());
    }

    private void HandleBack()
    {
        if (_model.TryGoBack()) Show(_model.GetCurrentNode());
    }

    public void SelectChoice(string nodeId)
    {
        if (_model.TryGoTo(nodeId)) Show(_model.GetCurrentNode());
    }

    private void Show(DialogNode node)
    {
        var data = BuildNodeData(node);

        _backgroundView.SetBackgroundSprite(data.Background);
        _charactersContainerView.ShowCharacters(data.Characters);
        _dialogWindowView.SetCharacterName(data.SpeakerName);
        _dialogWindowView.SetDialogText(data.Text);

        _choiceViewList.ClearChoices();
        if (data.NodeType == typeof(ChoiceNode))
        {
            _choiceViewList.SetChoices(data.Choices, SelectChoice);
        }
    }

    public DialogNodeData BuildNodeData(DialogNode node)
    {

        var charactersData = GetCharactersData(node.CharactersOnScene);

        var speakerData = GetSpeakerData(node.Speaker);

        var choicesData = node is ChoiceNode choiceNode
            ? GetChoicesData(choiceNode.Choices)
            : new List<ChoiceUIData>();

        return new DialogNodeData
        {
            Text = node.Text,
            Background = node.Background,
            SpeakerName = speakerData,
            Characters = charactersData,
            Choices = choicesData,
            NodeType = node.GetType()
        };
    }

    private List<CharacterToDisplay> GetCharactersData(List<CharacterState> characterStates)
    {
        var characters = characterStates.Select(c => new CharacterToDisplay
        {
            Id = c.CharacterId,
            Sprite = _characterLibrary.GetSprite(c.CharacterId, c.EmotionType)
        }).ToList();

        return characters;
    }

    private SpeakerNameUIData GetSpeakerData(Speaker speaker)
    {
        return new SpeakerNameUIData
        {
            SpeakerName = speaker.GetDisplayName(_characterLibrary),
            NameColor = speaker.GetDisplayColor(_characterLibrary)
        };
    }

    private List<ChoiceUIData> GetChoicesData(List<Choice> choices)
    {
        var choicesData = choices.Select(c => new ChoiceUIData
        {
            Text = c.Text,
            ChoiceId = c.NextNodeId
        }).ToList();

        return choicesData;
    }
}
