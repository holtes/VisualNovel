using Sirenix.OdinInspector;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class ChoiceNode : DialogNode
{
    [LabelText("����� ������")]
    [ListDrawerSettings(Expanded = true)]
    [OnValueChanged(nameof(SetAvailableNodesForChoices), IncludeChildren = true)]
    [SerializeField] private List<Choice> _choices = new();

    public List<Choice> Choices => _choices;

#if UNITY_EDITOR
    private void SetAvailableNodesForChoices()
    {
        foreach (var choice in _choices)
        {
            choice.SetAvailableNodes(_allNodes);
            choice.SetCurrentNode(this);
        }
    }
#endif
}
