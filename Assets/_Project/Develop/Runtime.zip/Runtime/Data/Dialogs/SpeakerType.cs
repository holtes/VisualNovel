public enum SpeakerType
{
    Character,
    Manual
}