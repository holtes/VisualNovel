public interface ICharacterConfigurable
{
    void SetConfig(CharactersConfig config);
}
