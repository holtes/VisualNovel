using System;
using UnityEngine;

[Serializable]
public struct CharacterEmotion
{
    public EmotionType type;
    public Sprite sprite;
}