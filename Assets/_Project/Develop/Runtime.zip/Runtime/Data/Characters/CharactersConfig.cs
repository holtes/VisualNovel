using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Dialog/Characters Config")]
public class CharactersConfig : ScriptableObject
{
    [SerializeField] private List<CharacterData> _characters = new();

    public List<CharacterData> Characters => _characters;
}