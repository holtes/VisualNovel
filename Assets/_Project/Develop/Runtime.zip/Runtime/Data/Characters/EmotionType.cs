public enum EmotionType
{
    Neutral,
    Happy,
    Sad,
    Angry,
    Surprised
}