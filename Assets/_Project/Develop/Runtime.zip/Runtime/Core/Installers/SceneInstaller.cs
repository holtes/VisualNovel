using _Project.Develop.Runtime.Data.Settings;
using UnityEngine;
using Zenject;

public class SceneInstaller : MonoInstaller
{
    [SerializeField] private GameConfig _gameConfig;
    [SerializeField] private CharactersConfig _charactersConfig;
    [SerializeField] private DialogConfig _dialogConfig;

    [SerializeField] private CharacterView _characterPrefab;
    [SerializeField] private ChoiceView _choicePrefab;

    public override void InstallBindings()
    {
        InstallGameConfig();
        InstallCharactersLibrary();
        InstallDialogModel();
        InstallCharacterPrefab();
        InstallChoicePrefab();
    }

    private void InstallGameConfig()
    {
        Container
            .Bind<GameConfig>()
            .FromInstance(_gameConfig);
    }

    private void InstallCharactersLibrary()
    {
        Container
            .Bind<ICharacterLibrary>()
            .To<CharacterLibraryFromConfig>()
            .AsSingle()
            .WithArguments(_charactersConfig);
    }

    private void InstallDialogModel()
    {
        Container
            .Bind<DialogModel>()
            .AsSingle()
            .WithArguments(_dialogConfig);
    }

    private void InstallCharacterPrefab()
    {
        Container
            .Bind<CharacterView>()
            .FromInstance(_characterPrefab);
    }

    private void InstallChoicePrefab()
    {
        Container
            .Bind<ChoiceView>()
            .FromInstance(_choicePrefab);
    }
}