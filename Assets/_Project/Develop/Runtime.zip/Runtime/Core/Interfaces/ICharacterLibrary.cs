using UnityEngine;

public interface ICharacterLibrary
{
    Sprite GetSprite(string characterId, EmotionType emotion);
    string GetDisplayName(string characterId);
    Color GetColor(string characterId);
}
